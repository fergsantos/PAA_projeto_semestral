import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Benchmark dos 5 algoritmos.
 * - Tamanhos: 100, 1.000, 5.000, 10.000, 50.000 e 100.000 (O(n²) só até 50.000).
 * - Tipos de dado: Aleatório (uniforme), Ordenado (crescente) e Inverso (decrescente).
 * - Cada caso roda 5 vezes; a 1ª (aquecimento) é descartada e tira-se a média das 4 seguintes.
 *
 * Uso: java Benchmark            (completo)
 *      java Benchmark 10000      (só tamanhos até 10.000, bem mais rápido)
 */
public class Benchmark {

    public static final int[] TAMANHOS = {100, 1000, 5000, 10000, 50000, 100000};
    public static final int LIMITE_QUADRATICO = 50000;
    public static final String[] TIPOS = {"Aleatório", "Ordenado", "Inverso"};
    public static final String[] NOMES = {"Bubble Sort", "Insertion Sort", "Selection Sort",
            "Merge Sort", "Quick Sort"};
    private static final int FAIXA_ALEATORIA = 1_000_000;
    private static final String ARQUIVO_CSV = "resultados_benchmark.csv";

    /** Gera o vetor do tipo pedido. O aleatório usa semente fixa (resultado reproduzível). */
    public static int[] gerar(String tipo, int n) {
        int[] v = new int[n];
        Random rnd = new Random(42);
        for (int i = 0; i < n; i++) {
            if (tipo.equals("Aleatório")) v[i] = rnd.nextInt(FAIXA_ALEATORIA);
            else if (tipo.equals("Ordenado")) v[i] = i;
            else v[i] = n - i;
        }
        return v;
    }

    /** 0 Bubble, 1 Insertion, 2 Selection, 3 Merge, 4 Quick. */
    public static Resultado executar(int alg, int[] v) {
        switch (alg) {
            case 0: return BubbleSort.ordenar(v);
            case 1: return InsertionSort.ordenar(v);
            case 2: return SelectionSort.ordenar(v);
            case 3: return MergeSort.ordenar(v);
            default: return QuickSort.ordenar(v);
        }
    }

    public static boolean quadratico(int alg) { return alg <= 2; }

    private static class Linha {
        String tipo;
        int n;
        int alg;
        Medicao medicao; // null = não executado
    }

    public static void main(String[] args) {
        int max = 100000;
        if (args.length > 0) {
            try {
                max = Integer.parseInt(args[0].replace(".", ""));
            } catch (NumberFormatException e) {
                System.out.println("Uso: java Benchmark [tamanhoMaximo]   (ex.: java Benchmark 10000)");
                return;
            }
        }

        int total = 0;
        for (int n : TAMANHOS)
            for (int a = 0; a < NOMES.length; a++)
                if (n <= max && !(quadratico(a) && n > LIMITE_QUADRATICO)) total++;
        total *= TIPOS.length;

        List<Linha> linhas = new ArrayList<>();
        int feitos = 0;
        long inicio = System.nanoTime();

        for (String tipo : TIPOS) {
            for (int n : TAMANHOS) {
                if (n > max) continue;
                int[] dados = gerar(tipo, n);
                for (int a = 0; a < NOMES.length; a++) {
                    Linha l = new Linha();
                    l.tipo = tipo; l.n = n; l.alg = a;
                    if (!(quadratico(a) && n > LIMITE_QUADRATICO)) {
                        System.err.printf("\r[%d/%d] %s | n=%d | %s            ", ++feitos, total, tipo, n, NOMES[a]);
                        Medicao m = new Medicao();
                        while (!m.completa()) {          // ao registrar a 5ª execução, o caso fica completo
                            m.registrar(executar(a, dados));
                        }
                        l.medicao = m;
                    }
                    linhas.add(l);
                }
            }
        }
        System.err.println("\rExecução concluída.                                        ");
        double segundos = (System.nanoTime() - inicio) / 1e9;

        imprimirTabelas(linhas);
        boolean validos = true, iguais = true;
        for (Linha l : linhas) {
            if (l.medicao != null) {
                validos &= l.medicao.isTodosValidos();
                iguais &= l.medicao.isContagensIguais();
            }
        }
        System.out.println("Todas as execuções validadas (ordenado + sem perda de elementos): " + (validos ? "SIM" : "NÃO"));
        System.out.println("Comparações e trocas idênticas nas 5 execuções de cada caso     : " + (iguais ? "SIM" : "NÃO"));
        System.out.printf("Tempo total do benchmark: %.1f s%n", segundos);
        try {
            gravarCsv(linhas);
            System.out.println("Resultados gravados em " + ARQUIVO_CSV + " (separador ';', decimal ',')");
        } catch (IOException e) {
            System.out.println("Não foi possível gravar o CSV: " + e.getMessage());
        }
    }

    private static void imprimirTabelas(List<Linha> linhas) {
        String ultimoTipo = "";
        int ultimoN = -1;
        for (Linha l : linhas) {
            if (!l.tipo.equals(ultimoTipo)) {
                System.out.println("\n" + repetir("=", 92));
                System.out.println("DADOS: " + l.tipo.toUpperCase()
                        + "   (5 execuções por caso; a 1ª é descartada; tempo = média das 4 seguintes)");
                System.out.println(repetir("=", 92));
                System.out.printf("%8s  %-15s %16s %16s %13s %12s  %s%n",
                        "n", "Algoritmo", "Comparações", "Trocas/Mov.", "Média (ms)", "Desvio (ms)", "Válido");
                ultimoTipo = l.tipo;
                ultimoN = -1;
            }
            if (l.n != ultimoN && ultimoN != -1) System.out.println();
            ultimoN = l.n;
            if (l.medicao == null) {
                System.out.printf("%8d  %-15s  não executado (O(n²) limitado a %d)%n",
                        l.n, NOMES[l.alg], LIMITE_QUADRATICO);
            } else {
                Resultado r = l.medicao.getUltimo();
                System.out.printf("%8d  %-15s %16d %16d %13.3f %12.3f  %s%n", l.n, NOMES[l.alg],
                        r.getComparacoes(), r.getTrocas(), l.medicao.mediaMs(), l.medicao.desvioMs(),
                        l.medicao.isTodosValidos() ? "SIM" : "NÃO");
            }
        }
        System.out.println();
    }

    private static void gravarCsv(List<Linha> linhas) throws IOException {
        Locale br = Locale.forLanguageTag("pt-BR");
        try (PrintWriter w = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(ARQUIVO_CSV), StandardCharsets.UTF_8))) {
            w.println("tipo;n;algoritmo;comparacoes;trocas_mov;media_ms;desvio_ms;"
                    + "exec1_aquecimento_ms;exec2_ms;exec3_ms;exec4_ms;exec5_ms;valido");
            for (Linha l : linhas) {
                if (l.medicao == null) {
                    w.println(l.tipo + ";" + l.n + ";" + NOMES[l.alg] + ";;;;;;;;;;nao executado");
                    continue;
                }
                Medicao m = l.medicao;
                Resultado r = m.getUltimo();
                StringBuilder sb = new StringBuilder();
                sb.append(l.tipo).append(';').append(l.n).append(';').append(NOMES[l.alg]).append(';')
                  .append(r.getComparacoes()).append(';').append(r.getTrocas()).append(';')
                  .append(String.format(br, "%.3f;%.3f", m.mediaMs(), m.desvioMs()));
                for (int i = 0; i < Medicao.EXECUCOES; i++) sb.append(';').append(String.format(br, "%.3f", m.getTempoMs(i)));
                sb.append(';').append(m.isTodosValidos() ? "sim" : "nao");
                w.println(sb);
            }
        }
    }

    private static String repetir(String texto, int vezes) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < vezes; i++) sb.append(texto);
        return sb.toString();
    }
}
