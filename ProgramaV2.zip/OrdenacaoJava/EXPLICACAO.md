# Algoritmos de ordenação em Java — Explicação do trabalho

## 1. Objetivo
Implementar cinco algoritmos de ordenação — **Bubble Sort**, **Insertion Sort**, **Selection Sort**, **Merge Sort** e **Quick Sort** — que:
- recebem um vetor de inteiros e o ordenam de forma **crescente**;
- **contam** comparações e trocas/movimentos e **medem** o tempo de execução;
- **validam** se o vetor ficou realmente ordenado;
- e, além disso, um programa de demonstração, um benchmark com médias de 5 execuções e um visualizador animado.

## 2. Estrutura do projeto

| Arquivo | Função |
|---|---|
| `BubbleSort.java`, `InsertionSort.java`, `SelectionSort.java`, `MergeSort.java`, `QuickSort.java` | Os cinco algoritmos, com contadores e tempo |
| `Resultado.java` | Guarda vetor ordenado, comparações, trocas, tempo (ns/ms) e validação |
| `Validador.java` | Confere ordem crescente e se nenhum elemento foi perdido |
| `Medicao.java` | Acumula as 5 execuções de um caso e calcula a média (descartando a 1ª) |
| `Benchmark.java` | Benchmark: 6 tamanhos × 3 tipos de dado × 5 algoritmos, com tabela e CSV |
| `Main.java` | Execução simples dos 5 algoritmos com um vetor de exemplo e um aleatório |
| `Demonstracao.java` | Passo a passo (Bubble e Insertion), relação entre métricas e comparação dos 5 |
| `Testes.java` | Testes automáticos (9727 verificações) |
| `visualizador_ordenacao.html` | Visualizador animado dos 5 algoritmos, com testes e benchmark no navegador |

## 3. Como cada algoritmo funciona

**Bubble Sort** — compara pares vizinhos e troca quando estão fora de ordem. A cada passada, o maior valor restante vai para o final. Se uma passada não faz nenhuma troca, o vetor já está ordenado e o algoritmo para (parada antecipada).

**Insertion Sort** — mantém uma parte ordenada à esquerda. Pega a próxima "chave", desloca para a direita os elementos maiores que ela e a insere na posição correta.

**Selection Sort** — a cada passo procura o menor valor da parte não ordenada e o coloca na primeira posição livre. Faz sempre n(n−1)/2 comparações (mesmo com o vetor ordenado), mas no máximo n−1 trocas.

**Merge Sort** — divide o vetor ao meio, ordena cada metade (recursão) e intercala as duas partes ordenadas usando um vetor auxiliar. Em **trocas/movimentos** contamos cada cópia de elemento (para o auxiliar e de volta ao vetor).

**Quick Sort** — escolhe um pivô (mediana de três: início, meio e fim), deixa os menores à esquerda e os maiores à direita (partição de Lomuto) e repete em cada lado. A recursão ocorre só no lado menor, mantendo a pilha em O(log n).

| Algoritmo | Melhor caso | Caso médio | Pior caso | Estável | Memória extra |
|---|---|---|---|---|---|
| Bubble Sort | O(n) | O(n²) | O(n²) | Sim | O(1) |
| Insertion Sort | O(n) | O(n²) | O(n²) | Sim | O(1) |
| Selection Sort | O(n²) | O(n²) | O(n²) | Não | O(1) |
| Merge Sort | O(n log n) | O(n log n) | O(n log n) | Sim | O(n) |
| Quick Sort | O(n log n) | O(n log n) | O(n²) | Não | O(log n) |

"Trocas" (Bubble, Selection, Quick) e "movimentos" (Insertion, Merge) não têm o mesmo custo; comparar esses números só faz sentido dentro do mesmo algoritmo ou da mesma família. A memória extra não inclui a cópia do vetor feita para não alterar o original.

## 4. O que é medido
- **Comparações:** cada vez que dois valores são comparados.
- **Trocas (Bubble, Selection, Quick):** cada troca de dois elementos.
- **Movimentos (Insertion):** cada deslocamento de um elemento uma posição à direita (a escrita final da chave não é contada).
- **Movimentos (Merge):** cada cópia de elemento (para o auxiliar e de volta ao vetor).
- **Tempo:** `System.nanoTime()` ao redor apenas da ordenação, em ns e em ms.
- **Validação:** o vetor deve estar em ordem crescente **e** ser uma permutação do original (comparado com `Arrays.sort`), garantindo que nenhum elemento foi perdido ou alterado.

## 5. Decisões de implementação
- O vetor recebido é **copiado** (`clone`); o original nunca é modificado.
- Vetor `null` lança `IllegalArgumentException` com mensagem clara.
- `Resultado` é imutável e devolve **cópia** do vetor ordenado.
- A validação fica **fora** da medição de tempo.
- O código usa só recursos do Java 8, então compila em qualquer JDK a partir dessa versão.

## 6. Protocolo do benchmark
Implementado em `Benchmark.java` e `Medicao.java`:
- **Tamanhos:** n = 100, 1.000, 5.000, 10.000, 50.000 e 100.000. Os algoritmos O(n²) (Bubble, Insertion e Selection) só vão até 50.000, para não inviabilizar a execução.
- **Tipos de dado:** Aleatório (distribuição uniforme em [0, 1.000.000), semente fixa 42), Ordenado (crescente) e Inverso (decrescente). Todos os algoritmos recebem exatamente o mesmo vetor.
- **Execuções:** cada caso (algoritmo + tamanho + tipo) roda **5 vezes**. A classe `Medicao` registra o tempo de cada execução e, quando a 5ª é registrada, reconhece que o caso está completo e calcula a **média das 4 últimas**: a 1ª execução é descartada por ser de aquecimento da JVM (compilação JIT). Também calcula o desvio padrão amostral.
- **Conferências automáticas:** todas as execuções são validadas, e as comparações e trocas devem ser idênticas nas 5 execuções de cada caso.
- **Saída:** uma tabela por tipo de dado e o arquivo `resultados_benchmark.csv` (separador `;`, decimal `,`, abre direto no Excel em português) com média, desvio e os 5 tempos de cada caso.

## 7. Como executar
```
javac -encoding UTF-8 *.java
java Benchmark                 # benchmark completo (n até 100.000); leva cerca de 1 minuto
java Benchmark 10000           # versão rápida (n até 10.000)
java Demonstracao              # passo a passo + comparação dos 5
java Demonstracao 9 4 7 1 3    # passo a passo com o seu vetor (até 15 números)
java Testes                    # testes automáticos
java Main                      # execução simples
```
Se os acentos aparecerem errados no terminal do Windows, use `java -Dfile.encoding=UTF-8 Benchmark`. No visualizador, o botão **Benchmark** roda o mesmo protocolo no navegador (escolha o tamanho máximo ao lado do botão).

## 8. Exemplo: vetor `[5, 3, 8, 1, 2, 7]`

| | Comparações | Trocas/Movimentos |
|---|---|---|
| Bubble Sort | 14 | 8 |
| Insertion Sort | 11 | 8 |

O vetor tem **8 inversões** (pares fora de ordem). Esse é exatamente o número de trocas do Bubble e de movimentos do Insertion: cada troca ou deslocamento desfaz uma inversão. O programa confere essa igualdade e também que os contadores do passo a passo batem com os das classes que medem as métricas.

## 9. Testes realizados (todos passaram)
No Java: `java Testes`. No visualizador: botão **Rodar testes**, com uma bateria equivalente.
- Casos de borda: vetor vazio, 1 elemento, já ordenado, inverso, valores repetidos, negativos e valores extremos (`Integer.MIN_VALUE` e `Integer.MAX_VALUE`).
- 500 vetores aleatórios, nos 5 algoritmos, comparados com `Arrays.sort`, conferindo também que o vetor original não muda.
- Vetores de 2000 elementos: ordenado, inverso, todos iguais e aleatório.
- Bubble e Insertion: trocas/movimentos iguais ao número de inversões; contagem exata (inverso → n(n−1)/2; ordenado → n−1 comparações e 0 trocas).
- Selection Sort: sempre n(n−1)/2 comparações e no máximo n−1 trocas. Merge Sort: comparações dentro do limite n·log₂(n).
- `Medicao`: só fica completa na 5ª execução, a média descarta a 1ª, o desvio está correto, a 6ª execução é recusada e divergências são detectadas.
- `Benchmark.gerar`: Ordenado cresce, Inverso decresce, Aleatório é reproduzível e fica na faixa. As 5 execuções reais de cada algoritmo têm contagens idênticas e resultados válidos.
- O `Validador` rejeita vetor desordenado e vetor com elemento alterado. Vetor `null` e cópia defensiva do resultado.

## 10. Resultados e conclusões
Contagens exatas (aleatório, semente 42): com 1.000 elementos, Bubble 496.574 comparações e Insertion 253.081, ambos com 252.088 trocas/movimentos. Com 5.000 elementos: Bubble 12.494.799, Selection 12.497.500, Insertion 6.257.244, Quick 67.218 e Merge 55.236 comparações.

Tempo médio (média das 4 execuções após o aquecimento) em um benchmark completo no ambiente de teste. No seu computador os valores serão diferentes; o que se mantém é a ordem de grandeza e a comparação entre os algoritmos.

**n = 50.000**

| Algoritmo | Aleatório (ms) | Ordenado (ms) | Inverso (ms) |
|---|---|---|---|
| Bubble Sort | 3727,628 | 0,019 | 2030,801 |
| Insertion Sort | 148,821 | 0,033 | 295,431 |
| Selection Sort | 470,153 | 468,134 | 496,650 |
| Merge Sort | 5,465 | 1,677 | 1,645 |
| Quick Sort | 3,776 | 0,679 | 1,404 |

**n = 100.000** (só os O(n log n))

| Algoritmo | Aleatório (ms) | Ordenado (ms) | Inverso (ms) |
|---|---|---|---|
| Merge Sort | 15,466 | 3,591 | 4,054 |
| Quick Sort | 7,776 | 1,432 | 3,214 |

- Em vetor **aleatório**, o Insertion faz cerca de **metade das comparações** do Bubble e foi muito mais rápido.
- Em vetor **ordenado**, Bubble e Insertion fazem n−1 comparações e nenhuma troca, por isso ficam na casa de centésimos de milissegundo; o Selection continua fazendo n(n−1)/2 comparações.
- Em vetor **inverso** (pior caso), Bubble e Insertion fazem n(n−1)/2 comparações e trocas, e continuam O(n²).
- O tempo do Selection Sort quase não muda com o tipo de dado, porque o número de comparações é sempre o mesmo.
- Merge e Quick Sort levaram poucos milissegundos mesmo com 100.000 elementos, enquanto, com 50.000 elementos, os O(n²) levaram de décimos de segundo a vários segundos nos casos aleatório e inverso.

## 11. Limitações
- O **tempo** depende da máquina, da JVM e da carga do computador; comparações e trocas, não (são determinísticas para o mesmo vetor). Em tamanhos pequenos (100 e 1.000) o tempo é muito curto e o desvio relativo é grande.
- "Troca" e "movimento" não têm o mesmo custo; veja a observação na seção 3.
- O Quick Sort (partição de Lomuto) pode degradar para O(n²) quando o vetor tem muitos valores repetidos (com todos os valores iguais e n = 1000 foram 502.497 comparações, cerca de n²/2); o Merge Sort não tem esse problema.
- No visualizador, os dados aleatórios do benchmark usam outro gerador que o do Java, então as contagens aleatórias diferem; o protocolo é o mesmo.
