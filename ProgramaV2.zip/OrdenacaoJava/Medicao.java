/**
 * Acumula as execuções de um mesmo caso (algoritmo + tamanho + tipo de dado).
 * A cada execução, o resultado é registrado. Quando a 5ª é registrada, o caso fica
 * "completo" e a média pode ser calculada: a 1ª execução (aquecimento da JVM) é
 * descartada e a média é feita sobre as 4 seguintes.
 */
public class Medicao {
    public static final int EXECUCOES = 5;

    private final long[] temposNs = new long[EXECUCOES];
    private int registradas = 0;
    private Resultado ultimo;
    private boolean todosValidos = true;
    private boolean contagensIguais = true;

    public void registrar(Resultado r) {
        if (completa()) {
            throw new IllegalStateException("As " + EXECUCOES + " execuções já foram registradas.");
        }
        if (ultimo != null && (ultimo.getComparacoes() != r.getComparacoes()
                || ultimo.getTrocas() != r.getTrocas())) {
            contagensIguais = false;
        }
        temposNs[registradas++] = r.getTempoNs();
        todosValidos &= r.isValido();
        ultimo = r;
    }

    /** Verdadeiro quando as 5 execuções já foram registradas. */
    public boolean completa() { return registradas == EXECUCOES; }

    public int getRegistradas() { return registradas; }

    /** Tempo da execução {@code indice} (0 a 4), em ms. A de índice 0 é o aquecimento. */
    public double getTempoMs(int indice) { return temposNs[indice] / 1_000_000.0; }

    /** Média dos tempos das execuções 2 a 5 (a 1ª é descartada), em ms. */
    public double mediaMs() {
        exigirCompleta();
        double soma = 0;
        for (int i = 1; i < EXECUCOES; i++) soma += temposNs[i];
        return soma / (EXECUCOES - 1) / 1_000_000.0;
    }

    /** Desvio padrão amostral dos tempos das execuções 2 a 5, em ms. */
    public double desvioMs() {
        exigirCompleta();
        double media = mediaMs(), soma = 0;
        for (int i = 1; i < EXECUCOES; i++) {
            double d = getTempoMs(i) - media;
            soma += d * d;
        }
        return Math.sqrt(soma / (EXECUCOES - 2));
    }

    public Resultado getUltimo()          { return ultimo; }
    public boolean isTodosValidos()       { return todosValidos; }
    public boolean isContagensIguais()    { return contagensIguais; }

    private void exigirCompleta() {
        if (!completa()) {
            throw new IllegalStateException("Faltam " + (EXECUCOES - registradas) + " execuções.");
        }
    }
}
