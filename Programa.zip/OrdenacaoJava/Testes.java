import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.function.Function;

/** Testes automáticos dos cinco algoritmos, do Validador e do Resultado. */
public class Testes {
    private static int verificacoes = 0;
    private static final String[] NOMES = {"Bubble", "Insertion", "Selection", "Merge", "Quick"};
    private static final List<Function<int[], Resultado>> ALGS = Arrays.asList(
            BubbleSort::ordenar, InsertionSort::ordenar, SelectionSort::ordenar,
            MergeSort::ordenar, QuickSort::ordenar);

    private static void verificar(boolean condicao, String descricao) {
        verificacoes++;
        if (!condicao) throw new AssertionError("FALHA: " + descricao);
    }

    private static void grupo(String nome, Runnable teste) {
        int antes = verificacoes;
        teste.run();
        System.out.println("OK - " + nome + " (" + (verificacoes - antes) + " verificações)");
    }

    private static long inversoes(int[] v) {
        long c = 0;
        for (int i = 0; i < v.length; i++)
            for (int j = i + 1; j < v.length; j++)
                if (v[i] > v[j]) c++;
        return c;
    }

    public static void main(String[] args) {
        Random rnd = new Random(7);
        List<int[]> casos = new ArrayList<>();
        casos.add(new int[]{});
        casos.add(new int[]{1});
        casos.add(new int[]{2, 1});
        casos.add(new int[]{1, 2, 3, 4});
        casos.add(new int[]{5, 4, 3, 2, 1});
        casos.add(new int[]{3, 3, 3});
        casos.add(new int[]{-5, 0, -5, 7, 2, 2, -1});
        casos.add(new int[]{Integer.MAX_VALUE, Integer.MIN_VALUE, 0, -1, Integer.MAX_VALUE, Integer.MIN_VALUE});
        for (int k = 0; k < 500; k++) {
            int[] v = new int[rnd.nextInt(61)];
            for (int i = 0; i < v.length; i++) v[i] = rnd.nextInt(101) - 50;
            casos.add(v);
        }

        grupo("os 5 algoritmos ordenam (bordas, extremos, 500 aleatórios), validam e preservam o original", () -> {
            for (int[] c : casos) {
                int[] ref = c.clone(), original = c.clone();
                Arrays.sort(ref);
                for (int a = 0; a < ALGS.size(); a++) {
                    Resultado r = ALGS.get(a).apply(c);
                    verificar(Arrays.equals(r.getVetorOrdenado(), ref), NOMES[a] + " ordena " + Arrays.toString(c));
                    verificar(r.isValido(), NOMES[a] + " valida");
                    verificar(Arrays.equals(c, original), NOMES[a] + " preserva o original");
                }
            }
        });

        grupo("vetores grandes (2000): ordenado, inverso, repetidos e aleatório", () -> {
            int n = 2000;
            int[][] gs = new int[4][n];
            for (int i = 0; i < n; i++) {
                gs[0][i] = i; gs[1][i] = n - i; gs[2][i] = 7; gs[3][i] = rnd.nextInt(1000);
            }
            for (int[] g : gs) {
                int[] ref = g.clone();
                Arrays.sort(ref);
                for (int a = 0; a < ALGS.size(); a++)
                    verificar(Arrays.equals(ALGS.get(a).apply(g).getVetorOrdenado(), ref), NOMES[a] + " grande");
            }
        });

        grupo("Bubble e Insertion: trocas/movimentos = número de inversões", () -> {
            for (int[] c : casos) {
                long inv = inversoes(c);
                verificar(BubbleSort.ordenar(c).getTrocas() == inv, "bubble inversões");
                verificar(InsertionSort.ordenar(c).getTrocas() == inv, "insertion inversões");
            }
        });

        grupo("contagem exata: inverso = n(n-1)/2, ordenado = n-1 comparações e 0 trocas (Bubble/Insertion)", () -> {
            for (int n : new int[]{2, 5, 10, 100}) {
                int[] inverso = new int[n], ordenado = new int[n];
                for (int i = 0; i < n; i++) { inverso[i] = n - i; ordenado[i] = i; }
                long max = (long) n * (n - 1) / 2;
                for (Function<int[], Resultado> f : ALGS.subList(0, 2)) {
                    Resultado r = f.apply(inverso);
                    verificar(r.getComparacoes() == max && r.getTrocas() == max, "inverso n=" + n);
                    r = f.apply(ordenado);
                    verificar(r.getComparacoes() == n - 1 && r.getTrocas() == 0, "ordenado n=" + n);
                }
            }
        });

        grupo("Selection Sort: sempre n(n-1)/2 comparações e no máximo n-1 trocas", () -> {
            for (int[] c : casos) {
                Resultado r = SelectionSort.ordenar(c);
                long n = c.length;
                verificar(r.getComparacoes() == n * (n - 1) / 2, "selection comparações");
                verificar(r.getTrocas() <= Math.max(0, n - 1), "selection trocas");
            }
        });

        grupo("Merge Sort: comparações dentro do limite n·log2(n)", () -> {
            for (int n : new int[]{2, 16, 1000, 4096}) {
                int[] v = new int[n];
                for (int i = 0; i < n; i++) v[i] = rnd.nextInt();
                long limite = (long) Math.ceil(n * (Math.log(n) / Math.log(2)));
                verificar(MergeSort.ordenar(v).getComparacoes() <= limite, "merge limite n=" + n);
            }
        });

        grupo("Validador rejeita vetor desordenado e vetor com elemento alterado", () -> {
            verificar(!Validador.validar(new int[]{3, 1, 2}, new int[]{3, 1, 2}), "desordenado");
            verificar(!Validador.validar(new int[]{3, 1, 2}, new int[]{1, 2, 2}), "elemento alterado");
            verificar(Validador.validar(new int[]{3, 1, 2}, new int[]{1, 2, 3}), "correto aceito");
        });

        grupo("vetor nulo lança IllegalArgumentException nos 5 algoritmos", () -> {
            for (int a = 0; a < ALGS.size(); a++) {
                try { ALGS.get(a).apply(null); verificar(false, NOMES[a] + " aceitou null"); }
                catch (IllegalArgumentException e) { verificar(true, ""); }
            }
        });

        grupo("getVetorOrdenado() devolve cópia", () -> {
            Resultado r = BubbleSort.ordenar(new int[]{3, 1, 2});
            r.getVetorOrdenado()[0] = 99;
            verificar(r.getVetorOrdenado()[0] == 1, "cópia defensiva");
        });

        System.out.println("\nTODOS OS TESTES PASSARAM (" + verificacoes + " verificações).");
    }
}
