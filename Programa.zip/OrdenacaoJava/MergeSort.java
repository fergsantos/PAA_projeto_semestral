/**
 * Merge Sort - O(n log n) sempre; usa vetor auxiliar.
 * "Trocas/movimentos" contam cada cópia de elemento (para o auxiliar e de volta ao vetor).
 */
public class MergeSort {

    public static Resultado ordenar(int[] vetor) {
        if (vetor == null) {
            throw new IllegalArgumentException("O vetor não pode ser nulo.");
        }
        int[] v = vetor.clone();
        long[] c = new long[2]; // c[0] = comparações, c[1] = movimentos

        long inicio = System.nanoTime();
        int[] auxiliar = new int[v.length];
        ordenar(v, auxiliar, 0, v.length - 1, c);
        long tempo = System.nanoTime() - inicio;

        return new Resultado("Merge Sort", v, c[0], c[1], tempo, Validador.validar(vetor, v));
    }

    private static void ordenar(int[] v, int[] aux, int inicio, int fim, long[] c) {
        if (inicio >= fim) return;
        int meio = inicio + (fim - inicio) / 2;
        ordenar(v, aux, inicio, meio, c);
        ordenar(v, aux, meio + 1, fim, c);
        intercalar(v, aux, inicio, meio, fim, c);
    }

    private static void intercalar(int[] v, int[] aux, int inicio, int meio, int fim, long[] c) {
        for (int k = inicio; k <= fim; k++) {
            aux[k] = v[k];
            c[1]++;
        }
        int i = inicio, j = meio + 1;
        for (int k = inicio; k <= fim; k++) {
            if (i > meio) {
                v[k] = aux[j++];
            } else if (j > fim) {
                v[k] = aux[i++];
            } else {
                c[0]++;
                v[k] = (aux[i] <= aux[j]) ? aux[i++] : aux[j++];
            }
            c[1]++;
        }
    }
}
