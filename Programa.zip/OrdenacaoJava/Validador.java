import java.util.Arrays;

/** Validação do resultado da ordenação. */
public class Validador {

    /** Verifica se o vetor está em ordem crescente. */
    public static boolean estaOrdenado(int[] v) {
        for (int i = 0; i < v.length - 1; i++) {
            if (v[i] > v[i + 1]) return false;
        }
        return true;
    }

    /** Ordenado crescente E permutação do original (nenhum elemento perdido). */
    public static boolean validar(int[] original, int[] ordenado) {
        int[] referencia = original.clone();
        Arrays.sort(referencia);
        return estaOrdenado(ordenado) && Arrays.equals(referencia, ordenado);
    }
}
