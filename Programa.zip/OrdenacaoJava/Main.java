import java.util.Arrays;
import java.util.Random;

public class Main {

    private static Resultado[] rodarTodos(int[] v) {
        return new Resultado[]{BubbleSort.ordenar(v), InsertionSort.ordenar(v),
                SelectionSort.ordenar(v), MergeSort.ordenar(v), QuickSort.ordenar(v)};
    }

    public static void main(String[] args) {
        Random rnd = new Random();

        // Aquecimento da JVM (JIT) para que a primeira medição não seja penalizada
        int[] aquecimento = new int[2000];
        for (int k = 0; k < 5; k++) {
            for (int i = 0; i < aquecimento.length; i++) aquecimento[i] = rnd.nextInt();
            rodarTodos(aquecimento);
        }

        // Exemplo com vetor fixo
        int[] exemplo = {64, 34, 25, 12, 22, 11, 90, 5};
        System.out.println("Vetor original: " + Arrays.toString(exemplo) + "\n");
        for (Resultado r : rodarTodos(exemplo)) r.imprimir(true);

        // Teste com vetor grande aleatório
        int[] grande = new int[2000];
        for (int i = 0; i < grande.length; i++) grande[i] = rnd.nextInt(20001) - 10000;
        System.out.println("=== Vetor aleatório com 2000 elementos ===\n");
        for (Resultado r : rodarTodos(grande)) r.imprimir(false);
    }
}
