/**
 * Quick Sort - O(n log n) em média. Pivô: mediana de três; partição de Lomuto;
 * recursão só no lado menor (pilha O(log n)). Com muitos valores repetidos pode chegar a O(n²).
 */
public class QuickSort {

    public static Resultado ordenar(int[] vetor) {
        if (vetor == null) {
            throw new IllegalArgumentException("O vetor não pode ser nulo.");
        }
        int[] v = vetor.clone();
        long[] c = new long[2]; // c[0] = comparações, c[1] = trocas

        long inicio = System.nanoTime();
        ordenar(v, 0, v.length - 1, c);
        long tempo = System.nanoTime() - inicio;

        return new Resultado("Quick Sort", v, c[0], c[1], tempo, Validador.validar(vetor, v));
    }

    private static void ordenar(int[] v, int inicio, int fim, long[] c) {
        while (inicio < fim) {
            int meio = inicio + (fim - inicio) / 2;
            c[0] += 3; // mediana de três: coloca a mediana em v[fim]
            if (v[meio] < v[inicio]) trocar(v, meio, inicio, c);
            if (v[fim] < v[inicio]) trocar(v, fim, inicio, c);
            if (v[meio] < v[fim]) trocar(v, meio, fim, c);

            int pivo = v[fim], i = inicio - 1;
            for (int j = inicio; j < fim; j++) {
                c[0]++;
                if (v[j] < pivo) trocar(v, ++i, j, c);
            }
            trocar(v, i + 1, fim, c);
            int p = i + 1;

            if (p - inicio < fim - p) {
                ordenar(v, inicio, p - 1, c);
                inicio = p + 1;
            } else {
                ordenar(v, p + 1, fim, c);
                fim = p - 1;
            }
        }
    }

    private static void trocar(int[] v, int a, int b, long[] c) {
        if (a != b) {
            int t = v[a]; v[a] = v[b]; v[b] = t;
            c[1]++;
        }
    }
}
