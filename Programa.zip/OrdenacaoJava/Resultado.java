import java.util.Arrays;

/** Guarda o resultado e as métricas de uma execução de ordenação. */
public class Resultado {
    private final String algoritmo;
    private final int[] vetorOrdenado;
    private final long comparacoes;
    private final long trocas; // Bubble: trocas | Insertion: movimentos (deslocamentos)
    private final long tempoNs;
    private final boolean valido;

    public Resultado(String algoritmo, int[] vetorOrdenado, long comparacoes,
                     long trocas, long tempoNs, boolean valido) {
        this.algoritmo = algoritmo;
        this.vetorOrdenado = vetorOrdenado;
        this.comparacoes = comparacoes;
        this.trocas = trocas;
        this.tempoNs = tempoNs;
        this.valido = valido;
    }

    public String getAlgoritmo()     { return algoritmo; }
    public int[] getVetorOrdenado()  { return vetorOrdenado.clone(); } // cópia defensiva
    public long getComparacoes()     { return comparacoes; }
    public long getTrocas()          { return trocas; }
    public long getTempoNs()         { return tempoNs; }
    public double getTempoMs()       { return tempoNs / 1_000_000.0; }
    public boolean isValido()        { return valido; }

    public void imprimir(boolean mostrarVetor) {
        System.out.println("--- " + algoritmo + " ---");
        if (mostrarVetor) System.out.println("Vetor ordenado : " + Arrays.toString(vetorOrdenado));
        System.out.println("Comparações    : " + comparacoes);
        System.out.println("Trocas/Mov.    : " + trocas);
        System.out.printf("Tempo          : %d ns (%.6f ms)%n", tempoNs, getTempoMs());
        System.out.println("Ordenado válido: " + (valido ? "SIM" : "NÃO") + "\n");
    }
}
