/** Selection Sort - O(n²): sempre n(n-1)/2 comparações; no máximo n-1 trocas. */
public class SelectionSort {

    public static Resultado ordenar(int[] vetor) {
        if (vetor == null) {
            throw new IllegalArgumentException("O vetor não pode ser nulo.");
        }
        int[] v = vetor.clone();
        int n = v.length;
        long comparacoes = 0, trocas = 0;

        long inicio = System.nanoTime();
        for (int i = 0; i < n - 1; i++) {
            int menor = i;
            for (int j = i + 1; j < n; j++) {
                comparacoes++;
                if (v[j] < v[menor]) menor = j;
            }
            if (menor != i) {
                int tmp = v[i];
                v[i] = v[menor];
                v[menor] = tmp;
                trocas++;
            }
        }
        long tempo = System.nanoTime() - inicio;

        return new Resultado("Selection Sort", v, comparacoes, trocas, tempo,
                Validador.validar(vetor, v));
    }
}
