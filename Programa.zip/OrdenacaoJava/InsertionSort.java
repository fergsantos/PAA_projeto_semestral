/** Insertion Sort - O(n²) no pior caso, O(n) no melhor caso. */
public class InsertionSort {

    public static Resultado ordenar(int[] vetor) {
        if (vetor == null) {
            throw new IllegalArgumentException("O vetor não pode ser nulo.");
        }
        int[] v = vetor.clone(); // cópia: não altera o vetor original
        long comparacoes = 0, movimentos = 0;

        long inicio = System.nanoTime();
        for (int i = 1; i < v.length; i++) {
            int chave = v[i];
            int j = i - 1;
            while (j >= 0) {
                comparacoes++;
                if (v[j] > chave) {
                    v[j + 1] = v[j]; // desloca elemento para a direita
                    movimentos++;
                    j--;
                } else {
                    break;
                }
            }
            v[j + 1] = chave;
        }
        long tempo = System.nanoTime() - inicio;

        return new Resultado("Insertion Sort", v, comparacoes, movimentos, tempo,
                Validador.validar(vetor, v));
    }
}
