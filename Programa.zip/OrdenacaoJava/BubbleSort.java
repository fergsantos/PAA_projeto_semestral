/** Bubble Sort - O(n²), com parada antecipada (melhor caso O(n)). */
public class BubbleSort {

    public static Resultado ordenar(int[] vetor) {
        if (vetor == null) {
            throw new IllegalArgumentException("O vetor não pode ser nulo.");
        }
        int[] v = vetor.clone(); // cópia: não altera o vetor original
        int n = v.length;
        long comparacoes = 0, trocas = 0;

        long inicio = System.nanoTime();
        for (int i = 0; i < n - 1; i++) {
            boolean houveTroca = false;
            for (int j = 0; j < n - 1 - i; j++) {
                comparacoes++;
                if (v[j] > v[j + 1]) {
                    int tmp = v[j];
                    v[j] = v[j + 1];
                    v[j + 1] = tmp;
                    trocas++;
                    houveTroca = true;
                }
            }
            if (!houveTroca) break; // já ordenado: encerra antecipadamente
        }
        long tempo = System.nanoTime() - inicio;

        return new Resultado("Bubble Sort", v, comparacoes, trocas, tempo,
                Validador.validar(vetor, v));
    }
}
