# Bubble Sort e Insertion Sort em Java — Explicação do trabalho

## 1. Objetivo
Implementar os algoritmos **Bubble Sort** e **Insertion Sort** que:
- recebem um vetor de inteiros e o ordenam de forma **crescente**;
- **contam** comparações e trocas/movimentos e **medem** o tempo de execução;
- **validam** se o vetor ficou realmente ordenado;
- e, além disso, um programa de demonstração que mostra o que cada algoritmo faz passo a passo.

## 2. Estrutura do projeto

| Arquivo | Função |
|---|---|
| `BubbleSort.java` | Algoritmo Bubble Sort com contadores e tempo |
| `InsertionSort.java` | Algoritmo Insertion Sort com contadores e tempo |
| `Resultado.java` | Guarda vetor ordenado, comparações, trocas, tempo (ns/ms) e validação |
| `Validador.java` | Confere ordem crescente e se nenhum elemento foi perdido |
| `Main.java` | Execução simples com um vetor de exemplo e um aleatório |
| `Demonstracao.java` | Passo a passo, relação entre métricas e comparação em vetores maiores |
| `Testes.java` | Testes automáticos (3066 verificações) |

## 3. Como cada algoritmo funciona

**Bubble Sort** — compara pares vizinhos e troca quando estão fora de ordem. A cada passada completa, o maior valor restante vai para o final. Se uma passada não faz nenhuma troca, o vetor já está ordenado e o algoritmo para (parada antecipada).

**Insertion Sort** — mantém uma parte ordenada à esquerda. Pega a próxima "chave", desloca para a direita os elementos maiores que ela e a insere na posição correta.

| | Melhor caso (já ordenado) | Caso médio | Pior caso (inverso) |
|---|---|---|---|
| Bubble Sort | O(n) | O(n²) | O(n²) |
| Insertion Sort | O(n) | O(n²) | O(n²) |

Ambos são **estáveis** (elementos iguais mantêm a ordem relativa) e ordenam **in-place** (memória extra O(1), além da cópia do vetor feita para não alterar o original).

## 4. O que é medido
- **Comparações:** cada vez que dois valores são comparados (`v[j] > v[j+1]` no Bubble; `v[j] > chave` no Insertion).
- **Trocas (Bubble):** cada troca de dois elementos vizinhos.
- **Movimentos (Insertion):** cada deslocamento de um elemento uma posição à direita. A escrita final da chave não é contada.
- **Tempo:** `System.nanoTime()` ao redor apenas da ordenação, em ns e em ms.
- **Validação:** o vetor deve estar em ordem crescente **e** ser uma permutação do original (comparado com `Arrays.sort`), garantindo que nenhum elemento foi perdido ou alterado.

## 5. Decisões de implementação
- O vetor recebido é **copiado** (`clone`); o original nunca é modificado.
- Vetor `null` lança `IllegalArgumentException` com mensagem clara.
- `Resultado` é imutável e devolve **cópia** do vetor ordenado.
- A validação fica **fora** da medição de tempo.
- Na comparação em vetores maiores, a JVM é **aquecida** antes (o JIT otimiza o código nas primeiras execuções) e o tempo reportado é a **mediana de 5 execuções**, para reduzir ruído.

## 6. Como executar
```
javac -encoding UTF-8 *.java
java Demonstracao              # passo a passo + comparação
java Demonstracao 9 4 7 1 3    # passo a passo com o seu vetor (até 15 números)
java Testes                    # testes automáticos
java Main                      # execução simples
```
Se os acentos aparecerem errados no terminal do Windows, use `java -Dfile.encoding=UTF-8 Demonstracao`.

## 7. Exemplo: vetor `[5, 3, 8, 1, 2, 7]`

| | Comparações | Trocas/Movimentos |
|---|---|---|
| Bubble Sort | 14 | 8 |
| Insertion Sort | 11 | 8 |

O vetor tem **8 inversões** (pares fora de ordem). Esse é exatamente o número de trocas do Bubble e de movimentos do Insertion: cada troca ou deslocamento desfaz uma inversão. O programa confere essa igualdade e também que os contadores do passo a passo batem com os das classes que medem as métricas.

## 8. Testes realizados (todos passaram)
- Casos de borda: vetor vazio, 1 elemento, já ordenado, inverso, valores repetidos e negativos.
- 500 vetores aleatórios comparados com `Arrays.sort`, conferindo também que o vetor original não muda.
- Trocas/movimentos iguais ao número de inversões.
- Contagem exata: vetor inverso → n(n−1)/2 comparações e trocas; vetor ordenado → n−1 comparações e 0 trocas.
- Valores extremos (`Integer.MIN_VALUE` e `Integer.MAX_VALUE`).
- O `Validador` rejeita vetor desordenado e vetor com elemento alterado.
- Vetor `null` e cópia defensiva do resultado.

## 9. Resultados e conclusões
Com 1000 elementos aleatórios (semente fixa 42): Bubble Sort com **498.275** comparações e Insertion Sort com **245.712**, ambos com cerca de 244.720 trocas/movimentos.

- Em vetor **aleatório**, o Insertion faz cerca de **metade das comparações** do Bubble e costuma ser mais rápido.
- Em vetor **já ordenado**, ambos fazem n−1 comparações e nenhuma troca.
- Em vetor **inverso** (pior caso), ambos fazem n(n−1)/2 comparações e trocas, e continuam O(n²).

## 10. Limitações
- O **tempo** depende da máquina, da JVM e da carga do computador; comparações e trocas, não (são determinísticas para o mesmo vetor).
- "Troca" (Bubble) e "movimento" (Insertion) não têm o mesmo custo: uma troca envolve três atribuições, um deslocamento envolve uma. Por isso os números coincidem, mas o Insertion tende a ser mais rápido.
- Para vetores grandes, nenhum dos dois é indicado; algoritmos O(n log n), como o Merge Sort, são bem melhores.
