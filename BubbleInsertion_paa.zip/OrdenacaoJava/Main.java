import java.util.Arrays;
import java.util.Random;

public class Main {

    /** Aquecimento da JVM (JIT) para que a primeira medição não seja penalizada. */
    private static void aquecer() {
        Random rnd = new Random(1);
        int[] v = new int[2000];
        for (int k = 0; k < 5; k++) {
            for (int i = 0; i < v.length; i++) v[i] = rnd.nextInt();
            BubbleSort.ordenar(v);
            InsertionSort.ordenar(v);
        }
    }

    public static void main(String[] args) {
        aquecer();

        // Exemplo com vetor fixo
        int[] exemplo = {64, 34, 25, 12, 22, 11, 90, 5};
        System.out.println("Vetor original: " + Arrays.toString(exemplo) + "\n");
        BubbleSort.ordenar(exemplo).imprimir(true);
        InsertionSort.ordenar(exemplo).imprimir(true);

        // Teste com vetor grande aleatório
        Random rnd = new Random();
        int[] grande = new int[2000];
        for (int i = 0; i < grande.length; i++) grande[i] = rnd.nextInt(20001) - 10000;
        System.out.println("=== Vetor aleatório com 2000 elementos ===\n");
        BubbleSort.ordenar(grande).imprimir(false);
        InsertionSort.ordenar(grande).imprimir(false);
    }
}
