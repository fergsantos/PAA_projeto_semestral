import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;

/**
 * Programa de demonstração: mostra passo a passo o que o Bubble Sort e o
 * Insertion Sort fazem, confere com as classes que medem as métricas e
 * compara os dois em vetores maiores.
 *
 * Uso: java Demonstracao            (usa vetor de exemplo)
 *      java Demonstracao 9 4 7 1 3  (usa o vetor informado, até 15 números)
 */
public class Demonstracao {

    private static final int[] EXEMPLO_PADRAO = {5, 3, 8, 1, 2, 7};
    private static final int MAX_PASSO_A_PASSO = 15;

    public static void main(String[] args) {
        int[] vetor = lerVetor(args);

        titulo("DEMONSTRAÇÃO: BUBBLE SORT E INSERTION SORT");
        System.out.println("Vetor de entrada: " + Arrays.toString(vetor));
        System.out.println("Objetivo: ordenar em ordem crescente, contando comparações,");
        System.out.println("trocas/movimentos e tempo, e validando o resultado.\n");

        // 1) Bubble Sort
        titulo("1) BUBBLE SORT - passo a passo");
        System.out.println("Ideia: compara pares vizinhos e troca se estiverem fora de ordem.");
        System.out.println("A cada passada, o maior valor restante vai para o final.");
        System.out.println("Legenda: (a b) = par comparado naquele momento.\n");
        long[] passosBubble = bubbleComPassos(vetor);
        Resultado bubble = BubbleSort.ordenar(vetor);
        confrontar(passosBubble, bubble);

        // 2) Insertion Sort
        titulo("2) INSERTION SORT - passo a passo");
        System.out.println("Ideia: mantém uma parte ordenada à esquerda; pega a próxima \"chave\",");
        System.out.println("desloca os maiores para a direita e insere a chave no lugar certo.\n");
        long[] passosInsertion = insertionComPassos(vetor);
        Resultado insertion = InsertionSort.ordenar(vetor);
        confrontar(passosInsertion, insertion);

        // 3) Relação entre as métricas
        titulo("3) RELAÇÃO ENTRE AS MÉTRICAS");
        long inv = inversoes(vetor);
        System.out.println("Inversões do vetor (pares fora de ordem) : " + inv);
        System.out.println("Trocas do Bubble Sort                    : " + bubble.getTrocas());
        System.out.println("Movimentos do Insertion Sort             : " + insertion.getTrocas());
        System.out.println("Os três valores coincidem? "
                + ((inv == bubble.getTrocas() && inv == insertion.getTrocas()) ? "SIM" : "NÃO"));
        System.out.println("(Cada troca/deslocamento desfaz exatamente uma inversão.)\n");

        // 4) Comparação em vetores maiores
        titulo("4) COMPARAÇÃO EM VETORES MAIORES (mediana de 5 execuções)");
        benchmark();

        // 5) Conclusões
        titulo("5) CONCLUSÕES");
        System.out.println("- Ambos são O(n²) no pior caso e no caso médio.");
        System.out.println("- Vetor já ordenado: ambos fazem n-1 comparações e 0 trocas (O(n)).");
        System.out.println("- Vetor inverso: ambos fazem n(n-1)/2 comparações e trocas (pior caso).");
        System.out.println("- Vetor aleatório: o Insertion faz cerca da metade das comparações do Bubble,");
        System.out.println("  com o mesmo número de trocas/movimentos, e costuma ser mais rápido.");
        System.out.println("- Em todos os casos o resultado foi validado (ordenado e sem perda de elementos).");
    }

    // ---------- Bubble Sort com impressão dos passos ----------
    private static long[] bubbleComPassos(int[] original) {
        int[] v = original.clone();
        int n = v.length;
        long comparacoes = 0, trocas = 0;

        for (int i = 0; i < n - 1; i++) {
            System.out.println("Passada " + (i + 1) + ":");
            boolean houveTroca = false;
            for (int j = 0; j < n - 1 - i; j++) {
                comparacoes++;
                int a = v[j], b = v[j + 1];
                boolean troca = a > b;
                if (troca) {
                    v[j] = b;
                    v[j + 1] = a;
                    trocas++;
                    houveTroca = true;
                }
                System.out.printf("  %d vs %d -> %-6s %s%n", a, b, troca ? "TROCA" : "mantém", marcar(v, j, j + 1));
            }
            System.out.println("  Fim da passada: " + Arrays.toString(v));
            if (!houveTroca) {
                System.out.println("  Nenhuma troca nesta passada: já está ordenado, para antes.");
                break;
            }
        }
        System.out.println();
        return new long[]{comparacoes, trocas};
    }

    // ---------- Insertion Sort com impressão dos passos ----------
    private static long[] insertionComPassos(int[] original) {
        int[] v = original.clone();
        long comparacoes = 0, movimentos = 0;

        for (int i = 1; i < v.length; i++) {
            int chave = v[i];
            System.out.println("Passo " + i + ": chave = " + chave
                    + " | parte ordenada = " + Arrays.toString(Arrays.copyOfRange(v, 0, i)));
            int j = i - 1;
            while (j >= 0) {
                comparacoes++;
                if (v[j] > chave) {
                    System.out.println("  " + v[j] + " > " + chave + " -> desloca " + v[j] + " para a direita");
                    v[j + 1] = v[j];
                    movimentos++;
                    j--;
                } else {
                    System.out.println("  " + v[j] + " <= " + chave + " -> achou o lugar da chave");
                    break;
                }
            }
            if (j < 0) System.out.println("  chegou ao início do vetor");
            v[j + 1] = chave;
            System.out.println("  insere " + chave + " na posição " + (j + 1) + " -> " + Arrays.toString(v));
        }
        System.out.println();
        return new long[]{comparacoes, movimentos};
    }

    private static void confrontar(long[] passos, Resultado real) {
        System.out.println("Resumo do passo a passo: " + passos[0] + " comparações, "
                + passos[1] + " trocas/movimentos.");
        boolean igual = passos[0] == real.getComparacoes() && passos[1] == real.getTrocas();
        System.out.println("Confere com a classe que mede as métricas (" + real.getAlgoritmo() + ")? "
                + (igual ? "SIM" : "NÃO") + "\n");
        real.imprimir(true);
    }

    // ---------- Comparação em vetores maiores ----------
    private static void benchmark() {
        aquecer();
        int[] tamanhos = {100, 1000, 5000};
        String[] casos = {"Aleatório", "Já ordenado", "Inverso"};

        System.out.printf("%-12s %6s  %-15s %12s %12s %12s  %s%n",
                "Caso", "n", "Algoritmo", "Comparações", "Trocas/Mov.", "Tempo (ms)", "Válido");
        System.out.println("-".repeat(86));
        for (int n : tamanhos) {
            for (String caso : casos) {
                int[] v = gerar(n, caso);
                linha(caso, n, mediana(true, v));
                linha(caso, n, mediana(false, v));
            }
            System.out.println();
        }
    }

    private static void linha(String caso, int n, Resultado r) {
        System.out.printf("%-12s %6d  %-15s %12d %12d %12.3f  %s%n", caso, n, r.getAlgoritmo(),
                r.getComparacoes(), r.getTrocas(), r.getTempoMs(), r.isValido() ? "SIM" : "NÃO");
    }

    /** Executa 5 vezes e devolve a execução de tempo mediano (comparações e trocas não variam). */
    private static Resultado mediana(boolean bubble, int[] v) {
        Resultado[] rs = new Resultado[5];
        for (int k = 0; k < rs.length; k++) {
            rs[k] = bubble ? BubbleSort.ordenar(v) : InsertionSort.ordenar(v);
        }
        Arrays.sort(rs, Comparator.comparingLong(Resultado::getTempoNs));
        return rs[rs.length / 2];
    }

    /** Aquecimento da JVM (JIT) para que a primeira medição não seja penalizada. */
    private static void aquecer() {
        int[] v = gerar(2000, "Aleatório");
        for (int k = 0; k < 5; k++) {
            BubbleSort.ordenar(v);
            InsertionSort.ordenar(v);
        }
    }

    private static int[] gerar(int n, String caso) {
        int[] v = new int[n];
        Random rnd = new Random(42);
        for (int i = 0; i < n; i++) {
            if (caso.equals("Aleatório")) v[i] = rnd.nextInt(100_000);
            else if (caso.equals("Já ordenado")) v[i] = i;
            else v[i] = n - i;
        }
        return v;
    }

    // ---------- Utilitários ----------
    private static long inversoes(int[] v) {
        long c = 0;
        for (int i = 0; i < v.length; i++)
            for (int j = i + 1; j < v.length; j++)
                if (v[i] > v[j]) c++;
        return c;
    }

    private static String marcar(int[] v, int a, int b) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < v.length; i++) {
            if (i == a) sb.append("(");
            sb.append(v[i]);
            if (i == b) sb.append(")");
            if (i < v.length - 1) sb.append(" ");
        }
        return sb.append("]").toString();
    }

    private static void titulo(String texto) {
        System.out.println("=".repeat(70));
        System.out.println(texto);
        System.out.println("=".repeat(70));
    }

    private static int[] lerVetor(String[] args) {
        if (args.length == 0) return EXEMPLO_PADRAO.clone();
        String texto = String.join(" ", args).replace(",", " ").trim();
        String[] partes = texto.isEmpty() ? new String[0] : texto.split("\\s+");
        if (partes.length == 0 || partes.length > MAX_PASSO_A_PASSO) {
            System.out.println("Informe de 1 a " + MAX_PASSO_A_PASSO + " números inteiros.");
            System.exit(1);
        }
        int[] v = new int[partes.length];
        for (int i = 0; i < partes.length; i++) {
            try {
                v[i] = Integer.parseInt(partes[i]);
            } catch (NumberFormatException e) {
                System.out.println("Valor inválido: \"" + partes[i] + "\". Use apenas números inteiros.");
                System.exit(1);
            }
        }
        return v;
    }
}
