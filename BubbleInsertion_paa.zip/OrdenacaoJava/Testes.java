import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/** Testes automáticos das classes BubbleSort, InsertionSort, Validador e Resultado. */
public class Testes {
    private static int verificacoes = 0;

    private static void verificar(boolean condicao, String descricao) {
        verificacoes++;
        if (!condicao) throw new AssertionError("FALHA: " + descricao);
    }

    private static void grupo(String nome, Runnable teste) {
        int antes = verificacoes;
        teste.run();
        System.out.println("OK - " + nome + " (" + (verificacoes - antes) + " verificações)");
    }

    private static long inversoes(int[] v) {
        long c = 0;
        for (int i = 0; i < v.length; i++)
            for (int j = i + 1; j < v.length; j++)
                if (v[i] > v[j]) c++;
        return c;
    }

    public static void main(String[] args) {
        Random rnd = new Random(7);

        List<int[]> casos = new ArrayList<>();
        casos.add(new int[]{});
        casos.add(new int[]{1});
        casos.add(new int[]{2, 1});
        casos.add(new int[]{1, 2, 3, 4});
        casos.add(new int[]{5, 4, 3, 2, 1});
        casos.add(new int[]{3, 3, 3});
        casos.add(new int[]{-5, 0, -5, 7, 2, 2, -1});
        for (int k = 0; k < 500; k++) {
            int[] v = new int[rnd.nextInt(61)];
            for (int i = 0; i < v.length; i++) v[i] = rnd.nextInt(101) - 50;
            casos.add(v);
        }

        grupo("ordena corretamente (bordas + 500 aleatórios), valida e preserva o original", () -> {
            for (int[] c : casos) {
                int[] original = c.clone(), ref = c.clone();
                Arrays.sort(ref);
                Resultado b = BubbleSort.ordenar(c), s = InsertionSort.ordenar(c);
                verificar(Arrays.equals(b.getVetorOrdenado(), ref), "bubble ordena " + Arrays.toString(c));
                verificar(Arrays.equals(s.getVetorOrdenado(), ref), "insertion ordena " + Arrays.toString(c));
                verificar(b.isValido() && s.isValido(), "validação " + Arrays.toString(c));
                verificar(Arrays.equals(c, original), "vetor original intacto");
            }
        });

        grupo("trocas/movimentos = número de inversões", () -> {
            for (int[] c : casos) {
                long inv = inversoes(c);
                verificar(BubbleSort.ordenar(c).getTrocas() == inv, "bubble inversões");
                verificar(InsertionSort.ordenar(c).getTrocas() == inv, "insertion inversões");
            }
        });

        grupo("contagem exata: inverso = n(n-1)/2 e ordenado = n-1 comparações, 0 trocas", () -> {
            for (int n : new int[]{2, 5, 10, 100}) {
                int[] inverso = new int[n], ordenado = new int[n];
                for (int i = 0; i < n; i++) { inverso[i] = n - i; ordenado[i] = i; }
                long max = (long) n * (n - 1) / 2;
                Resultado b = BubbleSort.ordenar(inverso), s = InsertionSort.ordenar(inverso);
                verificar(b.getComparacoes() == max && b.getTrocas() == max, "bubble inverso n=" + n);
                verificar(s.getComparacoes() == max && s.getTrocas() == max, "insertion inverso n=" + n);
                b = BubbleSort.ordenar(ordenado);
                s = InsertionSort.ordenar(ordenado);
                verificar(b.getComparacoes() == n - 1 && b.getTrocas() == 0, "bubble ordenado n=" + n);
                verificar(s.getComparacoes() == n - 1 && s.getTrocas() == 0, "insertion ordenado n=" + n);
            }
        });

        grupo("valores extremos (Integer.MIN_VALUE / MAX_VALUE)", () -> {
            int[] ext = {Integer.MAX_VALUE, Integer.MIN_VALUE, 0, -1, Integer.MAX_VALUE, Integer.MIN_VALUE};
            int[] ref = ext.clone();
            Arrays.sort(ref);
            verificar(Arrays.equals(BubbleSort.ordenar(ext).getVetorOrdenado(), ref), "bubble extremos");
            verificar(Arrays.equals(InsertionSort.ordenar(ext).getVetorOrdenado(), ref), "insertion extremos");
        });

        grupo("Validador rejeita vetor desordenado e vetor com elemento alterado", () -> {
            verificar(!Validador.validar(new int[]{3, 1, 2}, new int[]{3, 1, 2}), "desordenado");
            verificar(!Validador.validar(new int[]{3, 1, 2}, new int[]{1, 2, 2}), "elemento alterado");
            verificar(Validador.validar(new int[]{3, 1, 2}, new int[]{1, 2, 3}), "correto aceito");
        });

        grupo("vetor nulo lança IllegalArgumentException", () -> {
            try { BubbleSort.ordenar(null); verificar(false, "bubble aceitou null"); }
            catch (IllegalArgumentException e) { verificar(true, ""); }
            try { InsertionSort.ordenar(null); verificar(false, "insertion aceitou null"); }
            catch (IllegalArgumentException e) { verificar(true, ""); }
        });

        grupo("getVetorOrdenado() devolve cópia", () -> {
            Resultado r = BubbleSort.ordenar(new int[]{3, 1, 2});
            r.getVetorOrdenado()[0] = 99;
            verificar(r.getVetorOrdenado()[0] == 1, "cópia defensiva");
        });

        System.out.println("\nTODOS OS TESTES PASSARAM (" + verificacoes + " verificações).");
    }
}
