
public class MergeSort {

    public static Estatisticas ordenar(int[] v) {
        Estatisticas stats = new Estatisticas();
        long inicio = System.nanoTime();

        int[] auxiliar = new int[v.length];
        mergeSort(v, auxiliar, 0, v.length - 1, stats);

        stats.tempoNs = System.nanoTime() - inicio;
        stats.ordenado = Verificador.estaOrdenado(v);
        return stats;
    }

    private static void mergeSort(int[] v, int[] auxiliar, int inicio, int fim, Estatisticas stats) {
        if (inicio >= fim) {
            return; 
        }

        int meio = inicio + (fim - inicio) / 2; // evita overflow de int
        mergeSort(v, auxiliar, inicio, meio, stats);
        mergeSort(v, auxiliar, meio + 1, fim, stats);
        merge(v, auxiliar, inicio, meio, fim, stats);
    }

    private static void merge(int[] v, int[] auxiliar, int inicio, int meio, int fim, Estatisticas stats) {
        
        for (int k = inicio; k <= fim; k++) {
            auxiliar[k] = v[k];
            stats.trocas++; 
        }

        int i = inicio;      
        int j = meio + 1;    

        for (int k = inicio; k <= fim; k++) {
            if (i > meio) {
                
                v[k] = auxiliar[j++];
                stats.trocas++;
            } else if (j > fim) {
                
                v[k] = auxiliar[i++];
                stats.trocas++;
            } else {
                stats.comparacoes++;
                if (auxiliar[i] <= auxiliar[j]) {
                    v[k] = auxiliar[i++];
                } else {
                    v[k] = auxiliar[j++];
                }
                stats.trocas++; 
            }
        }
    }
}
