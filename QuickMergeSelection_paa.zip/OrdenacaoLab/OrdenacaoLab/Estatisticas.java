/**
 * Guarda os números que cada algoritmo precisa reportar:
 * comparações, trocas (ou movimentos) e tempo de execução.
 * Cada classe de ordenação devolve um objeto deste tipo.
 */
public class Estatisticas {
    public long comparacoes = 0;
    public long trocas = 0;      // trocas (swap) ou movimentos, dependendo do algoritmo
    public long tempoNs = 0;     // tempo de execução em nanossegundos
    public boolean ordenado = false;

    public double tempoMs() {
        return tempoNs / 1_000_000.0;
    }

    @Override
    public String toString() {
        return String.format(
            "comparações=%d | trocas/movimentos=%d | tempo=%.3f ms | ordenado=%s",
            comparacoes, trocas, tempoMs(), ordenado
        );
    }
}
