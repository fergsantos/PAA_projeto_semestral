
public class QuickSort {

    public static Estatisticas ordenar(int[] v) {
        Estatisticas stats = new Estatisticas();
        long inicio = System.nanoTime();

        quickSort(v, 0, v.length - 1, stats);

        stats.tempoNs = System.nanoTime() - inicio;
        stats.ordenado = Verificador.estaOrdenado(v);
        return stats;
    }

    private static void quickSort(int[] v, int inicio, int fim, Estatisticas stats) {
        // Recursão apenas na parte menor; a maior vira laço. Isso limita a
        // profundidade da pilha a O(log n) e evita StackOverflowError.
        while (inicio < fim) {
            escolherPivo(v, inicio, fim, stats);
            int posPivo = particionar(v, inicio, fim, stats);
            if (posPivo - inicio < fim - posPivo) {
                quickSort(v, inicio, posPivo - 1, stats);
                inicio = posPivo + 1;
            } else {
                quickSort(v, posPivo + 1, fim, stats);
                fim = posPivo - 1;
            }
        }
    }

    // Mediana de três (início, meio, fim): coloca a mediana em v[fim],
    // evitando o pior caso em vetores já ordenados ou inversamente ordenados.
    private static void escolherPivo(int[] v, int inicio, int fim, Estatisticas stats) {
        int meio = inicio + (fim - inicio) / 2;
        stats.comparacoes += 3;
        if (v[meio] < v[inicio]) trocar(v, meio, inicio, stats);
        if (v[fim] < v[inicio]) trocar(v, fim, inicio, stats);
        if (v[meio] < v[fim]) trocar(v, meio, fim, stats);
    }

    private static int particionar(int[] v, int inicio, int fim, Estatisticas stats) {
        int pivo = v[fim];
        int i = inicio - 1; 

        for (int j = inicio; j < fim; j++) {
            stats.comparacoes++;
            if (v[j] < pivo) {
                i++;
                trocar(v, i, j, stats);
            }
        }

        trocar(v, i + 1, fim, stats); 
        return i + 1;
    }

    private static void trocar(int[] v, int a, int b, Estatisticas stats) {
        if (a != b) {
            int temp = v[a];
            v[a] = v[b];
            v[b] = temp;
            stats.trocas++;
        }
    }
}
