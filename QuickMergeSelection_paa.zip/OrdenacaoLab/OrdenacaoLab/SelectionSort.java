
public class SelectionSort {

    
    public static Estatisticas ordenar(int[] v) {
        Estatisticas stats = new Estatisticas();
        long inicio = System.nanoTime();

        int n = v.length;
        for (int i = 0; i < n - 1; i++) {
            int indiceMenor = i;

            for (int j = i + 1; j < n; j++) {
                stats.comparacoes++;
                if (v[j] < v[indiceMenor]) {
                    indiceMenor = j;
                }
            }

            if (indiceMenor != i) {
                trocar(v, i, indiceMenor);
                stats.trocas++;
            }
        }

        stats.tempoNs = System.nanoTime() - inicio;
        stats.ordenado = Verificador.estaOrdenado(v);
        return stats;
    }

    private static void trocar(int[] v, int a, int b) {
        int temp = v[a];
        v[a] = v[b];
        v[b] = temp;
    }
}
