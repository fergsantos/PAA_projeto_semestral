import java.util.Arrays;
import java.util.Random;

/**
 * Programa principal: gera vetores aleatórios de inteiros, ordena cada
 * cópia com Selection Sort, Merge Sort e Quick Sort, e imprime uma
 * tabela comparando comparações, trocas/movimentos, tempo de execução
 * e se o resultado ficou realmente ordenado.
 */
public class Main {

    static int[] gerarVetorAleatorio(int n, long semente) {
        Random r = new Random(semente);
        int[] v = new int[n];
        for (int i = 0; i < n; i++) {
            v[i] = r.nextInt(10 * n); // valores entre 0 e 10n, com repetições possíveis
        }
        return v;
    }

    public static void main(String[] args) {
        int[] tamanhos = {100, 1000, 5000, 10000};
        long semente = 42;

        System.out.println("=== Laboratório de Ordenação: Selection Sort x Merge Sort x Quick Sort ===\n");

        for (int n : tamanhos) {
            int[] original = gerarVetorAleatorio(n, semente);

            System.out.println("---------------------------------------------------------------");
            System.out.println("n = " + n);
            System.out.println("---------------------------------------------------------------");
            System.out.printf("%-14s | %12s | %18s | %12s | %9s%n",
                    "Algoritmo", "Comparações", "Trocas/Movimentos", "Tempo (ms)", "Ordenado");
            System.out.println("---------------------------------------------------------------");

            rodar("Selection Sort", original, Main::ordenarSelection);
            rodar("Merge Sort", original, Main::ordenarMerge);
            rodar("Quick Sort", original, Main::ordenarQuick);

            System.out.println();
        }

        System.out.println("=== Teste com os exemplos pequenos (conferência manual) ===\n");
        testesPequenos();
    }

    interface Ordenador {
        Estatisticas ordenar(int[] v);
    }

    static Estatisticas ordenarSelection(int[] v) { return SelectionSort.ordenar(v); }
    static Estatisticas ordenarMerge(int[] v) { return MergeSort.ordenar(v); }
    static Estatisticas ordenarQuick(int[] v) { return QuickSort.ordenar(v); }

    static void rodar(String nome, int[] original, Ordenador ordenador) {
        int[] copia = Arrays.copyOf(original, original.length);
        Estatisticas stats = ordenador.ordenar(copia);
        System.out.printf("%-14s | %12d | %18d | %12.3f | %9s%n",
                nome, stats.comparacoes, stats.trocas, stats.tempoMs(), stats.ordenado);
    }

    static void testesPequenos() {
        int[][] vetores = {
                {5, 2, 9, 1, 5, 6},
                {1},
                {},
                {3, 3, 3, 3},
                {9, 8, 7, 6, 5, 4, 3, 2, 1}
        };

        for (int[] vOriginal : vetores) {
            System.out.println("Entrada: " + Arrays.toString(vOriginal));

            int[] v1 = Arrays.copyOf(vOriginal, vOriginal.length);
            Estatisticas s1 = SelectionSort.ordenar(v1);
            System.out.println("  Selection Sort -> " + Arrays.toString(v1) + "  (" + s1 + ")");

            int[] v2 = Arrays.copyOf(vOriginal, vOriginal.length);
            Estatisticas s2 = MergeSort.ordenar(v2);
            System.out.println("  Merge Sort     -> " + Arrays.toString(v2) + "  (" + s2 + ")");

            int[] v3 = Arrays.copyOf(vOriginal, vOriginal.length);
            Estatisticas s3 = QuickSort.ordenar(v3);
            System.out.println("  Quick Sort     -> " + Arrays.toString(v3) + "  (" + s3 + ")");

            System.out.println();
        }
    }
}
